#ifndef __USART1_H
#define __USART1_H

void usart1_init(void);

#endif
