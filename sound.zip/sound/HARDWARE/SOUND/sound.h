#ifndef __SOUND_H
#define __SOUND_H

void sound_init(void);
void US_100_get_data(void); 

#endif
