#include "stm32f10x.h"
#include "delay.h"
#include <stdio.h>

void sound_init(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;	//��ʼ��GPIO 7�Ž�echo
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE);
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_7;	
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPD;
	GPIO_Init(GPIOA, &GPIO_InitStructure);
	
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_6;	//6�Ž�trig
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;	
	GPIO_Init(GPIOA, &GPIO_InitStructure);
}


void US_100_get_data(void)
{
	int us = 0;
	double distance = 0.0;
	int dt = 0;	//��ʱʱ��
	GPIO_ResetBits(GPIOA,GPIO_Pin_6); //�͵�ƽ
	delay_us(5);
	GPIO_SetBits(GPIOA,GPIO_Pin_6);  //�ߵ�ƽ��ʼ����
	delay_us(10);
	GPIO_ResetBits(GPIOA,GPIO_Pin_6);	//�������
	
	while(0 == GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_7))
	{
		delay_us(1);
		if(dt++ >= 1000000)
		{
			printf("error\n");
			return ;
		}
	} //�����͵�ƽʱ��  ��ʱ�����
	while(1 == GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_7))
	{
		delay_us(20);
		us+=20;
	}//��ȡ�ߵ�ƽ����ʱ��
	printf("time : %d us\n",us);
	distance = ((double)us)/59; //���� ��λ cm
	printf("distance : %lf cm\n",distance);
}

