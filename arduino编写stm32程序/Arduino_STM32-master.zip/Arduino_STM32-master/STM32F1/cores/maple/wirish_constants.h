#ifndef _WIRING_CONSTANTS_
#define _WIRING_CONSTANTS_

#ifdef __cplusplus
extern "C"{
#endif

enum BitOrder {
	LSBFIRST = 0,
	MSBFIRST = 1
};

#ifdef __cplusplus
}
#endif

#endif
