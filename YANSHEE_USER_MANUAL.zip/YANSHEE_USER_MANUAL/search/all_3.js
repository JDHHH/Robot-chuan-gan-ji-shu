var searchData=
[
  ['fangervalue',['fAngerValue',['../struct__FaceExpression.html#ac1f0e7d7cf8240e4cc9b5b2ba879cb9b',1,'_FaceExpression']]],
  ['fdisgustvalue',['fDisgustValue',['../struct__FaceExpression.html#af96f0a5817083719a963f554adf8ed6a',1,'_FaceExpression']]],
  ['ffearvalue',['fFearValue',['../struct__FaceExpression.html#a15f3ff83347a30c4d2c1e54cad8215b4',1,'_FaceExpression']]],
  ['fhappinessvalue',['fHappinessValue',['../struct__FaceExpression.html#a40d06424c5ab47a4238a7d9e310f7586',1,'_FaceExpression']]],
  ['fneutralvalue',['fNeutralValue',['../struct__FaceExpression.html#a87e52a0d9f999eb4ba82e582384147c4',1,'_FaceExpression']]],
  ['fsadnessvalue',['fSadnessValue',['../struct__FaceExpression.html#a82119c2e82af6319696f764ca6ad1094',1,'_FaceExpression']]],
  ['fsurprisevalue',['fSurpriseValue',['../struct__FaceExpression.html#a9858e66e6750597f6f9d86676d870868',1,'_FaceExpression']]]
];
