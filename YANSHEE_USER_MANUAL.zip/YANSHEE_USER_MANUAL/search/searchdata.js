var indexSectionsWithContent =
{
  0: "_adfimrsu",
  1: "_",
  2: "r",
  3: "u",
  4: "adfis",
  5: "u",
  6: "u",
  7: "u",
  8: "mu"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "enums",
  7: "enumvalues",
  8: "defines"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Enumerations",
  7: "Enumerator",
  8: "Macros"
};

