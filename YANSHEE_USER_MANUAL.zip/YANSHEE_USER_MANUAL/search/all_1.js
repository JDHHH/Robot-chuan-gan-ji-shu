var searchData=
[
  ['acipaddr',['acIPAddr',['../struct__RobotInfo.html#aca220e4bd42b444cc5f105c4ceaf2760',1,'_RobotInfo']]],
  ['acname',['acName',['../struct__RobotInfo.html#a0dc600adfbf72150e776f100d6ec80ad',1,'_RobotInfo']]]
];
