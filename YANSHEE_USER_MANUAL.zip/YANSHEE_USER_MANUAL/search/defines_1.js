var searchData=
[
  ['ubtedu_5frobot_5fip_5faddr_5flen',['UBTEDU_ROBOT_IP_ADDR_LEN',['../RobotApi_8h.html#ab92db2df9ca7c3c48ff6495f9bafc53d',1,'RobotApi.h']]],
  ['ubtedu_5frobot_5fname_5flen',['UBTEDU_ROBOT_NAME_LEN',['../RobotApi_8h.html#aa37c5da3aea28e1d6eb93c3950ac7afe',1,'RobotApi.h']]],
  ['ubtedu_5fsdk_5fsw_5fver',['UBTEDU_SDK_SW_VER',['../RobotApi_8h.html#a15b516e476ff8db35f494b5c3798019b',1,'RobotApi.h']]]
];
